// Problem 2 : Given any character, if it is a vowel print "Vowel"

c = "c";
if (c == "a" || c == "e" || c == "i" || c == "o" || c == "u") {
  console.log("Vowel");
} else {
  console.log("Consonants");
}
