// Problem 3 : Given and character if it is a consonant print "Consonant"

c = "z";
(c == "a" || c == "e" || c == "i" || c == "o" || c == "u") ? console.log("Vowel") : console.log("Consonants");