c = "z";
(c == "a" || c == "e" || c == "i" || c == "o" || c ==  "u")?  console.log("Vowel"):console.log("Consonants");