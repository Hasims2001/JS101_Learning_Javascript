// Problem 5: Given the days of the week in short format "Sun", "Mon" ... print in long format "Sunday", "Monday", ...

day = "sun";

switch(day){
  case "sun":
    console.log("Sunday");
    break;
  case "mon":
    console.log("Monday");
    break;
  case "tue":
    console.log("Tueday");
    break;
  case "wed":
    console.log("Wednesday");
    break;
  case "thus":
    console.log("Thusday");
    break;
  case "fir":
    console.log("Friday");
    break;
  case "sat":
    console.log("Saturday");
    break;
}